# KS Kasir Pro — proyek sumber Android (versi awal)

Proyek Android Kotlin + Jetpack Compose untuk kasir offline-first. Ini adalah **proyek sumber/starter**, bukan APK rilis yang sudah dibangun atau diuji di perangkat.

## Identitas awal
- Nama aplikasi: KS Kasir Pro
- Nama toko awal: Kriuk Bakar Polaris
- Alamat awal: Jl. Negla Hilir No. 2/171A, RT 09 RW 04, Isola, Sukasari, Kota Bandung 40154
- Produk contoh awal: Ubi Milky Cream Cheese — kategori Minuman, harga jual Rp15.000, modal Rp13.000, stok 30
- Target Android: Android 13 atau lebih baru yang kompatibel; minSdk 26
- Printer yang dituju: printer struk Bluetooth 58 mm (belum diuji)

## Fitur yang ada pada source saat ini
- Antarmuka berbahasa Indonesia dan kategori Makanan, Minuman, Dessert, Tebus Murah.
- Produk contoh awal sesuai data yang diberikan; formulir tambah produk menyimpan nama, kategori, harga jual, modal, dan stok.
- Penyimpanan lokal sederhana menggunakan SharedPreferences/JSON untuk produk, pengaturan toko, dan riwayat transaksi.
- Keranjang multi-produk, validasi stok, metode pembayaran sebagai pencatatan, hitung kembalian tunai, dan pengurangan stok saat transaksi dicatat.
- Riwayat transaksi dan struk teks yang dapat dibagikan ke aplikasi lain.
- Pengaturan nama toko, alamat toko, dan teks struk.
- Penyesuaian stok sederhana.

## Belum tersedia dan harus dikerjakan sebelum operasional
- **APK belum berhasil dibangun atau diuji** pada lingkungan ini; Android SDK/Gradle tidak tersedia di lingkungan pembuatan saat ini.
- Sinkronisasi cloud belum diimplementasikan. Memerlukan pemilihan layanan, konfigurasi proyek, dan kredensial yang aman.
- QRIS statis/dinamis belum menerima atau memverifikasi pembayaran. Metode di layar hanya mencatat pilihan; QRIS dinamis memerlukan penyedia pembayaran dan kredensial merchant.
- Cetak Bluetooth ESC/POS langsung belum diimplementasikan; saat ini struk teks dibagikan melalui Android Sharesheet. Printer fisik perlu diuji.
- Foto produk, backup/restore, ekspor laporan, stok opname dengan penyesuaian kuantitas langsung, login/role, audit log, barcode, pajak/diskon, dan database Room belum tersedia.
- Perhitungan laporan keuntungan lengkap belum tersedia; angka modal/keuntungan perlu diverifikasi sebelum dipakai untuk keputusan bisnis.

## Build APK debug
Cara termudah tanpa komputer adalah menjalankan workflow GitHub Actions yang disertakan. Ini membutuhkan akun GitHub dan unggahan proyek ke repository milik pengguna.
1. Buat repository GitHub baru dan unggah seluruh isi folder proyek ini, termasuk `.github/workflows/android.yml`.
2. Buka tab **Actions**, pilih **Build KS Kasir Pro APK**, lalu pilih **Run workflow** (atau push ke `main`/`master`).
3. Jika workflow gagal, buka log dan perbaiki penyebabnya; build belum dijamin lolos.
4. Jika berhasil, unduh artifact `KS-Kasir-Pro-debug-apk`, ekstrak, lalu instal `app-debug.apk` di Android.
5. APK debug hanya untuk uji coba. Sebelum dipakai sungguhan, uji transaksi, pemulihan data, metode pembayaran, dan printer.

Jangan memasukkan kredensial merchant, kunci API, atau data pelanggan ke repository publik. Jangan menerima pembayaran QRIS nyata hanya berdasarkan pilihan metode pembayaran pada aplikasi.
