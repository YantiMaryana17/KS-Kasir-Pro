package com.kskasirpro.app

import android.os.Bundle
import org.json.JSONArray
import org.json.JSONObject
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import java.text.NumberFormat
import java.util.Locale

private val idr = NumberFormat.getCurrencyInstance(Locale("in", "ID")).apply { maximumFractionDigits = 0 }
private fun rupiah(value: Int) = idr.format(value).replace("Rp", "Rp ")

data class Product(val id: Int, val name: String, val category: String, val price: Int, val stock: Int, val cost: Int = 0)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = lightColorScheme(primary = androidx.compose.ui.graphics.Color(0xFF173B68), secondary = androidx.compose.ui.graphics.Color(0xFF18865B))) { KasirApp() } }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun KasirApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("ks_kasir_settings", 0) }
    var storeName by remember { mutableStateOf(prefs.getString("store_name", "Kriuk Bakar Polaris") ?: "Kriuk Bakar Polaris") }
    var storeAddress by remember { mutableStateOf(prefs.getString("store_address", "Jl. Negla Hilir No. 2/171A, RT 09 RW 04, Isola, Sukasari, Kota Bandung 40154") ?: "Jl. Negla Hilir No. 2/171A, RT 09 RW 04, Isola, Sukasari, Kota Bandung 40154") }
    var page by remember { mutableStateOf("Kasir") }
    var category by remember { mutableStateOf("Semua") }
    var query by remember { mutableStateOf("") }
    var payment by remember { mutableStateOf("Tunai") }
    var paidText by remember { mutableStateOf("") }
    var notice by remember { mutableStateOf("") }
    var showAddProduct by remember { mutableStateOf(false) }
    var newName by remember { mutableStateOf("") }
    var newCategory by remember { mutableStateOf("Makanan") }
    var newPrice by remember { mutableStateOf("") }
    var newCost by remember { mutableStateOf("") }
    var newStock by remember { mutableStateOf("") }
    var receiptHeader by remember { mutableStateOf(prefs.getString("receipt_header", "Terima kasih telah berbelanja!") ?: "Terima kasih telah berbelanja!") }
    var receiptFooter by remember { mutableStateOf(prefs.getString("receipt_footer", "Simpan struk ini sebagai bukti pembayaran.") ?: "Simpan struk ini sebagai bukti pembayaran.") }
    var sales by remember { mutableStateOf(prefs.getString("sales_json", "[]") ?: "[]") }
    val products = remember { mutableStateListOf<Product>() }
    fun saveProducts() {
        val a = JSONArray()
        products.forEach { p -> a.put(JSONObject().put("id",p.id).put("name",p.name).put("category",p.category).put("price",p.price).put("stock",p.stock).put("cost",p.cost)) }
        prefs.edit().putString("products_json", a.toString()).apply()
    }
    LaunchedEffect(Unit) {
        val saved = prefs.getString("products_json", null)
        if (saved != null) try { val a=JSONArray(saved); for(i in 0 until a.length()){ val o=a.getJSONObject(i); products.add(Product(o.getInt("id"),o.getString("name"),o.getString("category"),o.getInt("price"),o.getInt("stock"),o.optInt("cost", 0))) } } catch (_: Exception) {}
        if (products.isEmpty()) {
            products.add(Product(1, "Ubi Milky Cream Cheese", "Minuman", 15000, 30, 13000))
            saveProducts()
        }
    }
    val cart = remember { mutableStateMapOf<Int, Int>() }
    val total = products.sumOf { p -> p.price * (cart[p.id] ?: 0) }
    val categories = listOf("Semua", "Makanan", "Minuman", "Dessert", "Tebus Murah")
    Scaffold(topBar = { TopAppBar(title = { Column { Text("KS Kasir Pro", fontWeight = FontWeight.Bold); Text(storeName, style = MaterialTheme.typography.labelMedium) } }, actions = { IconButton(onClick = { page = "Pengaturan" }) { Icon(Icons.Default.Settings, "Pengaturan") } }) },
        bottomBar = { NavigationBar { listOf("Beranda", "Kasir", "Produk", "Transaksi", "Stok").forEach { item -> NavigationBarItem(selected = page == item, onClick = { page = item }, icon = { Icon(when(item){"Beranda"->Icons.Default.Home;"Kasir"->Icons.Default.ShoppingCart;"Produk"->Icons.Default.Inventory;"Transaksi"->Icons.Default.ReceiptLong;else->Icons.Default.Warehouse}, item) }, label = { Text(item) }) } } }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            when (page) {
                "Pengaturan" -> {
                    Text("Pengaturan toko", style = MaterialTheme.typography.headlineSmall)
                    Spacer(Modifier.height(12.dp)); OutlinedTextField(storeName, { storeName = it }, label = { Text("Nama toko pada struk") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(storeAddress, { storeAddress = it }, label = { Text("Alamat toko pada struk") }, modifier = Modifier.fillMaxWidth())
                    Button(onClick = { prefs.edit().putString("store_name", storeName).putString("store_address", storeAddress).apply(); notice = "Nama dan alamat toko tersimpan" }) { Text("Simpan identitas toko") }
                    Spacer(Modifier.height(16.dp))
                    OutlinedTextField(receiptHeader, { receiptHeader = it }, label = { Text("Teks penutup struk") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(receiptFooter, { receiptFooter = it }, label = { Text("Teks tambahan struk") }, modifier = Modifier.fillMaxWidth())
                    Button(onClick = { prefs.edit().putString("receipt_header", receiptHeader).putString("receipt_footer", receiptFooter).apply(); notice = "Pengaturan toko dan struk tersimpan." }) { Text("Simpan pengaturan") }
                    Text("Data produk dan pengaturan disimpan di perangkat ini. Sinkronisasi cloud, QRIS terverifikasi, dan cetak Bluetooth langsung belum aktif.", style = MaterialTheme.typography.bodySmall)
                }
                "Beranda" -> {
                    Text("Ringkasan", style = MaterialTheme.typography.headlineSmall)
                    Card(Modifier.fillMaxWidth().padding(top = 12.dp), shape = RoundedCornerShape(16.dp)) { Column(Modifier.padding(20.dp)) { Text("Total keranjang saat ini"); Text(rupiah(total), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold); Text("${cart.values.sum()} item dipilih") } }
                    Text("Pintasan", Modifier.padding(top = 20.dp), style = MaterialTheme.typography.titleMedium)
                    Button(onClick = { page = "Kasir" }, Modifier.fillMaxWidth()) { Text("Buka Kasir") }
                    Text("Produk dan pengaturan tersimpan secara lokal di perangkat.", style = MaterialTheme.typography.bodySmall)
                }
                "Kasir" -> {
                    OutlinedTextField(query, { query = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Cari menu") }, leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true)
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { categories.forEach { c -> FilterChip(selected = category == c, onClick = { category = c }, label = { Text(c) }) } }
                    LazyColumn(Modifier.weight(1f)) {
                        items(products.filter { (category == "Semua" || it.category == category) && it.name.contains(query, true) }) { p ->
                            ListItem(headlineContent = { Text(p.name, fontWeight = FontWeight.SemiBold) }, supportingContent = { Text("${p.category} • Stok contoh: ${p.stock}") }, trailingContent = { Row(verticalAlignment = Alignment.CenterVertically) { Text(rupiah(p.price)); IconButton(onClick = { cart[p.id] = (cart[p.id] ?: 0) + 1 }) { Icon(Icons.Default.AddCircle, "Tambah") } } })
                            HorizontalDivider()
                        }
                    }
                    Card(Modifier.fillMaxWidth().padding(top = 8.dp)) { Column(Modifier.padding(12.dp)) {
                        Text("Keranjang • ${cart.values.sum()} item", fontWeight = FontWeight.Bold)
                        if (cart.isEmpty()) Text("Pilih menu untuk memulai transaksi")
                        cart.toMap().forEach { (id, qty) -> products.find { it.id == id }?.let { p -> Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) { Text("${p.name} × $qty", Modifier.weight(1f)); Text(rupiah(p.price * qty)); IconButton(onClick = { if (qty <= 1) cart.remove(id) else cart[id] = qty - 1 }) { Icon(Icons.Default.RemoveCircleOutline, "Kurangi") } } } }
                        Text("TOTAL  ${rupiah(total)}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { Button(onClick = { page = "Pembayaran" }, enabled = cart.isNotEmpty(), modifier = Modifier.weight(1f)) { Text("Bayar") }; OutlinedButton(onClick = { cart.clear() }, enabled = cart.isNotEmpty()) { Text("Kosongkan") } }
                    } }
                }
                "Pembayaran" -> {
                    Text("Pembayaran", style = MaterialTheme.typography.headlineSmall)
                    Text("Total: ${rupiah(total)}", style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(vertical = 12.dp))
                    listOf("Tunai", "QRIS Statis", "QRIS Dinamis", "Transfer Bank", "Dompet Digital").forEach { m -> Row(verticalAlignment = Alignment.CenterVertically) { RadioButton(selected = payment == m, onClick = { payment = m }); Text(m) } }
                    OutlinedTextField(paidText, { paidText = it.filter(Char::isDigit) }, label = { Text("Uang diterima (untuk tunai)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
                    Text("Kembalian: ${rupiah(((paidText.toIntOrNull() ?: 0) - total).coerceAtLeast(0))}", modifier = Modifier.padding(vertical = 8.dp))
                    Button(onClick = {
                        if (payment == "Tunai" && (paidText.toIntOrNull() ?: 0) < total) { notice = "Uang diterima kurang dari total." }
                        else if (cart.any { (id, qty) -> (products.find { it.id == id }?.stock ?: 0) < qty }) { notice = "Stok tidak mencukupi. Periksa keranjang." }
                        else {
                            val change = if(payment == "Tunai") ((paidText.toIntOrNull() ?: total)-total).coerceAtLeast(0) else 0
                            val receipt = buildString { appendLine(storeName); appendLine(storeAddress); appendLine("Transaksi KS-${System.currentTimeMillis()}"); appendLine(java.text.SimpleDateFormat("dd-MM-yyyy HH:mm", Locale("id","ID")).format(java.util.Date())); appendLine("--------------------------------"); cart.toMap().forEach { (id,qty) -> products.find { it.id==id }?.let { appendLine("${it.name} x$qty  ${rupiah(it.price*qty)}") } }; appendLine("TOTAL ${rupiah(total)}"); appendLine("Bayar: $payment"); if(payment=="Tunai") { appendLine("Diterima: ${rupiah(paidText.toIntOrNull() ?: total)}"); appendLine("Kembali: ${rupiah(change)}") }; appendLine("--------------------------------"); appendLine(receiptHeader); appendLine(receiptFooter) }
                            val a = try { JSONArray(sales) } catch (_: Exception) { JSONArray() }
                            a.put(JSONObject().put("id", "KS-${System.currentTimeMillis()}").put("date", System.currentTimeMillis()).put("total", total).put("payment", payment).put("receipt", receipt))
                            sales = a.toString(); prefs.edit().putString("sales_json", sales).apply()
                            cart.toMap().forEach { (id,qty) -> val i=products.indexOfFirst { it.id==id }; if(i>=0) products[i]=products[i].copy(stock=products[i].stock-qty) }; saveProducts(); cart.clear(); paidText=""; page="Transaksi"; notice="Transaksi berhasil disimpan di perangkat.\n\n$receipt\n\nGunakan tombol bagikan untuk mengirim teks struk ke aplikasi pencetak yang kompatibel."
                        }
                    }, modifier = Modifier.fillMaxWidth()) { Text("Simpan & selesaikan transaksi") }
                    TextButton(onClick = { page = "Kasir" }) { Text("Kembali ke kasir") }
                }
                "Produk" -> {
                    Row(verticalAlignment=Alignment.CenterVertically, modifier=Modifier.fillMaxWidth()) { Text("Daftar Produk", style=MaterialTheme.typography.headlineSmall, modifier=Modifier.weight(1f)); Button(onClick={ showAddProduct=true }) { Text("+ Produk") } }
                    LazyColumn { items(products) { p -> ListItem(headlineContent={Text(p.name)}, supportingContent={Text("${p.category} • Jual ${rupiah(p.price)} • Modal ${rupiah(p.cost)} • stok ${p.stock}")}, trailingContent={ IconButton(onClick={ val i=products.indexOfFirst{it.id==p.id}; if(i>=0){products[i]=p.copy(stock=p.stock+1);saveProducts()} }) { Icon(Icons.Default.Add, "Tambah stok") } }) } }
                    if(showAddProduct) AlertDialog(onDismissRequest={showAddProduct=false}, title={Text("Tambah produk")}, text={Column { OutlinedTextField(newName,{newName=it},label={Text("Nama produk")}); OutlinedTextField(newPrice,{newPrice=it.filter(Char::isDigit)},label={Text("Harga jual")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number)); OutlinedTextField(newCost,{newCost=it.filter(Char::isDigit)},label={Text("Modal per produk (opsional)")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number)); OutlinedTextField(newStock,{newStock=it.filter(Char::isDigit)},label={Text("Stok awal")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number)); Text("Kategori"); Row { listOf("Makanan","Minuman","Dessert","Tebus Murah").forEach { c -> TextButton(onClick={newCategory=c}) { Text(if(newCategory==c) "✓ $c" else c) } } } } }, confirmButton={TextButton(onClick={ val price=newPrice.toIntOrNull(); val stock=newStock.toIntOrNull(); val cost = newCost.toIntOrNull() ?: 0; if(newName.isNotBlank() && price!=null && price>0 && stock!=null && cost>=0){ products.add(Product((products.maxOfOrNull{it.id}?:0)+1,newName,newCategory,price,stock,cost));saveProducts();newName="";newPrice="";newCost="";newStock="";showAddProduct=false;notice="Produk berhasil ditambahkan." } else notice="Lengkapi nama, harga, dan stok dengan benar." }){Text("Simpan")}}, dismissButton={TextButton(onClick={showAddProduct=false}){Text("Batal")}})
                }
                "Transaksi" -> { Text("Riwayat Transaksi", style = MaterialTheme.typography.headlineSmall); val arr=try{JSONArray(sales)}catch(_:Exception){JSONArray()}; if(arr.length()==0) Text("Belum ada transaksi.") else LazyColumn { items((0 until arr.length()).reversed().toList()) { ix -> val o=arr.getJSONObject(ix); ListItem(headlineContent={Text(o.optString("id"))}, supportingContent={Text("${java.text.SimpleDateFormat("dd-MM-yyyy HH:mm", Locale("id","ID")).format(java.util.Date(o.optLong("date")))} • ${o.optString("payment")}")}, trailingContent={Text(rupiah(o.optInt("total")))}); TextButton(onClick={notice=o.optString("receipt")}){Text("Lihat struk")}; TextButton(onClick={ val send=Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT,o.optString("receipt")); context.startActivity(Intent.createChooser(send,"Bagikan/cetak struk")) }){Text("Bagikan / cetak")}; HorizontalDivider() } } }
                "Stok" -> { Text("Stok & Opname", style = MaterialTheme.typography.headlineSmall); Text("Tekan + untuk mencatat penambahan stok."); LazyColumn { items(products) { p -> ListItem(headlineContent={Text(p.name)}, supportingContent={Text("Stok saat ini: ${p.stock}")}, trailingContent={Row(verticalAlignment=Alignment.CenterVertically){ IconButton(onClick={val i=products.indexOfFirst{it.id==p.id};if(i>=0 && products[i].stock>0){products[i]=p.copy(stock=p.stock-1);saveProducts()}}){Icon(Icons.Default.Remove,"Kurangi stok")};IconButton(onClick={val i=products.indexOfFirst{it.id==p.id};if(i>=0){products[i]=p.copy(stock=p.stock+1);saveProducts()}}){Icon(Icons.Default.Add,"Tambah stok")} }}) } } }
            }
            if (notice.isNotBlank()) AlertDialog(onDismissRequest = { notice = "" }, confirmButton = { TextButton(onClick = { notice = "" }) { Text("OK") } }, title = { Text("KS Kasir Pro") }, text = { Text(notice) })
        }
    }
}
